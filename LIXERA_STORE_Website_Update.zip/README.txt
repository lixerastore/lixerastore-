LIXERA STORE — Website order bot WhatsApp (static, free to host)

ISI:
- public/index.html : halaman order
- public/qris.jpg   : QRIS yang diberikan

CARA DEPLOY KE VERCEL:
1. Ekstrak ZIP ini.
2. Buka https://vercel.com dan login.
3. Cara paling mudah: buat repository GitHub baru, upload isi folder ini (folder public dan file vercel.json).
4. Di Vercel pilih Add New → Project, impor repository tersebut, lalu Deploy.
5. Framework Preset: Other. Build Command dan Output Directory dikosongkan (atau Output Directory = public jika Vercel meminta).
6. Setelah online, buka URL .vercel.app untuk mengetes semua tombol.
7. Untuk domain milikmu: Project → Settings → Domains → masukkan domain, lalu ikuti persis instruksi DNS yang ditampilkan Vercel di tempat domain dibeli. DNS dapat butuh waktu untuk aktif.

CATATAN:
- Website ini tidak memiliki database/order dashboard. Order dikirim ke WhatsApp admin setelah pelanggan menekan tombol konfirmasi.
- QRIS adalah gambar statis. Admin tetap harus memeriksa dana masuk di aplikasi merchant sebelum mengaktifkan layanan.
- Jangan menaruh secret key/API key di file frontend.
- Nomor admin diset ke 628818238317.
